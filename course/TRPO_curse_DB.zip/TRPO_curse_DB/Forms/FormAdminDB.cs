﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TRPO_curse_DB
{
    public partial class FormAdminDB : Form
    {
        public FormAdminDB()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //if (arrUsersDT[indexLogin, 0] == "admin" || arrUsersDT[indexLogin, 0] == "owner")
            //{
            //    FormAdminDB fAdb = new FormAdminDB();
            //    fAdb.ShowDialog();
            //    //fDB.Show();//Для одновременного использования(-hide, -ShowDialog, -close -(убрать))
            //}
            //else
            //{
            //    FormUsersDB fUdb = new FormUsersDB();
            //    fUdb.ShowDialog();
            //}
            //this.Close();//Что бы не просто скрывалась, а ещё не занимала память
        }
    }
}

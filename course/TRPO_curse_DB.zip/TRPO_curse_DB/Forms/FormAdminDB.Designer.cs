﻿namespace TRPO_curse_DB
{
    partial class FormAdminDB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlAdminDB = new System.Windows.Forms.TabControl();
            this.tabPageUsers = new System.Windows.Forms.TabPage();
            this.tabPageTeachers = new System.Windows.Forms.TabPage();
            this.tabPageFaculty = new System.Windows.Forms.TabPage();
            this.tabPageCathedra = new System.Windows.Forms.TabPage();
            this.tabPageHours = new System.Windows.Forms.TabPage();
            this.tabPageWages = new System.Windows.Forms.TabPage();
            this.dataGridViewUsers = new System.Windows.Forms.DataGridView();
            this.dataGridViewTeachers = new System.Windows.Forms.DataGridView();
            this.dataGridViewFaculty = new System.Windows.Forms.DataGridView();
            this.dataGridViewCathedra = new System.Windows.Forms.DataGridView();
            this.dataGridViewHours = new System.Windows.Forms.DataGridView();
            this.dataGridViewWages = new System.Windows.Forms.DataGridView();
            this.buttonExit = new System.Windows.Forms.Button();
            this.tabControlAdminDB.SuspendLayout();
            this.tabPageUsers.SuspendLayout();
            this.tabPageTeachers.SuspendLayout();
            this.tabPageFaculty.SuspendLayout();
            this.tabPageCathedra.SuspendLayout();
            this.tabPageHours.SuspendLayout();
            this.tabPageWages.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTeachers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFaculty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCathedra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWages)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlAdminDB
            // 
            this.tabControlAdminDB.Controls.Add(this.tabPageUsers);
            this.tabControlAdminDB.Controls.Add(this.tabPageTeachers);
            this.tabControlAdminDB.Controls.Add(this.tabPageFaculty);
            this.tabControlAdminDB.Controls.Add(this.tabPageCathedra);
            this.tabControlAdminDB.Controls.Add(this.tabPageHours);
            this.tabControlAdminDB.Controls.Add(this.tabPageWages);
            this.tabControlAdminDB.Location = new System.Drawing.Point(-4, 1);
            this.tabControlAdminDB.Name = "tabControlAdminDB";
            this.tabControlAdminDB.SelectedIndex = 0;
            this.tabControlAdminDB.Size = new System.Drawing.Size(499, 276);
            this.tabControlAdminDB.TabIndex = 0;
            // 
            // tabPageUsers
            // 
            this.tabPageUsers.Controls.Add(this.dataGridViewUsers);
            this.tabPageUsers.Location = new System.Drawing.Point(4, 22);
            this.tabPageUsers.Name = "tabPageUsers";
            this.tabPageUsers.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageUsers.Size = new System.Drawing.Size(491, 250);
            this.tabPageUsers.TabIndex = 0;
            this.tabPageUsers.Text = "Users";
            this.tabPageUsers.UseVisualStyleBackColor = true;
            // 
            // tabPageTeachers
            // 
            this.tabPageTeachers.Controls.Add(this.dataGridViewTeachers);
            this.tabPageTeachers.Location = new System.Drawing.Point(4, 22);
            this.tabPageTeachers.Name = "tabPageTeachers";
            this.tabPageTeachers.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTeachers.Size = new System.Drawing.Size(491, 250);
            this.tabPageTeachers.TabIndex = 1;
            this.tabPageTeachers.Text = "Teachers";
            this.tabPageTeachers.UseVisualStyleBackColor = true;
            // 
            // tabPageFaculty
            // 
            this.tabPageFaculty.Controls.Add(this.dataGridViewFaculty);
            this.tabPageFaculty.Location = new System.Drawing.Point(4, 22);
            this.tabPageFaculty.Name = "tabPageFaculty";
            this.tabPageFaculty.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFaculty.Size = new System.Drawing.Size(491, 250);
            this.tabPageFaculty.TabIndex = 2;
            this.tabPageFaculty.Text = "Faculty";
            this.tabPageFaculty.UseVisualStyleBackColor = true;
            // 
            // tabPageCathedra
            // 
            this.tabPageCathedra.Controls.Add(this.dataGridViewCathedra);
            this.tabPageCathedra.Location = new System.Drawing.Point(4, 22);
            this.tabPageCathedra.Name = "tabPageCathedra";
            this.tabPageCathedra.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCathedra.Size = new System.Drawing.Size(491, 250);
            this.tabPageCathedra.TabIndex = 3;
            this.tabPageCathedra.Text = "Cathedra";
            this.tabPageCathedra.UseVisualStyleBackColor = true;
            // 
            // tabPageHours
            // 
            this.tabPageHours.Controls.Add(this.dataGridViewHours);
            this.tabPageHours.Location = new System.Drawing.Point(4, 22);
            this.tabPageHours.Name = "tabPageHours";
            this.tabPageHours.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHours.Size = new System.Drawing.Size(491, 250);
            this.tabPageHours.TabIndex = 4;
            this.tabPageHours.Text = "Hours";
            this.tabPageHours.UseVisualStyleBackColor = true;
            // 
            // tabPageWages
            // 
            this.tabPageWages.Controls.Add(this.dataGridViewWages);
            this.tabPageWages.Location = new System.Drawing.Point(4, 22);
            this.tabPageWages.Name = "tabPageWages";
            this.tabPageWages.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWages.Size = new System.Drawing.Size(491, 250);
            this.tabPageWages.TabIndex = 5;
            this.tabPageWages.Text = "Wages";
            this.tabPageWages.UseVisualStyleBackColor = true;
            // 
            // dataGridViewUsers
            // 
            this.dataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUsers.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewUsers.Name = "dataGridViewUsers";
            this.dataGridViewUsers.Size = new System.Drawing.Size(491, 250);
            this.dataGridViewUsers.TabIndex = 1;
            // 
            // dataGridViewTeachers
            // 
            this.dataGridViewTeachers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTeachers.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewTeachers.Name = "dataGridViewTeachers";
            this.dataGridViewTeachers.Size = new System.Drawing.Size(491, 250);
            this.dataGridViewTeachers.TabIndex = 2;
            // 
            // dataGridViewFaculty
            // 
            this.dataGridViewFaculty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFaculty.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewFaculty.Name = "dataGridViewFaculty";
            this.dataGridViewFaculty.Size = new System.Drawing.Size(491, 250);
            this.dataGridViewFaculty.TabIndex = 2;
            // 
            // dataGridViewCathedra
            // 
            this.dataGridViewCathedra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCathedra.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewCathedra.Name = "dataGridViewCathedra";
            this.dataGridViewCathedra.Size = new System.Drawing.Size(491, 250);
            this.dataGridViewCathedra.TabIndex = 2;
            // 
            // dataGridViewHours
            // 
            this.dataGridViewHours.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHours.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewHours.Name = "dataGridViewHours";
            this.dataGridViewHours.Size = new System.Drawing.Size(491, 250);
            this.dataGridViewHours.TabIndex = 2;
            // 
            // dataGridViewWages
            // 
            this.dataGridViewWages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWages.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewWages.Name = "dataGridViewWages";
            this.dataGridViewWages.Size = new System.Drawing.Size(491, 250);
            this.dataGridViewWages.TabIndex = 2;
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(420, 353);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "Разавторизация";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // FormAdminDB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 373);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.tabControlAdminDB);
            this.Name = "FormAdminDB";
            this.Text = "FormAdminDB";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControlAdminDB.ResumeLayout(false);
            this.tabPageUsers.ResumeLayout(false);
            this.tabPageTeachers.ResumeLayout(false);
            this.tabPageFaculty.ResumeLayout(false);
            this.tabPageCathedra.ResumeLayout(false);
            this.tabPageHours.ResumeLayout(false);
            this.tabPageWages.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTeachers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFaculty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCathedra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWages)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlAdminDB;
        private System.Windows.Forms.TabPage tabPageUsers;
        private System.Windows.Forms.TabPage tabPageTeachers;
        private System.Windows.Forms.TabPage tabPageFaculty;
        private System.Windows.Forms.TabPage tabPageCathedra;
        private System.Windows.Forms.TabPage tabPageHours;
        private System.Windows.Forms.TabPage tabPageWages;
        private System.Windows.Forms.DataGridView dataGridViewUsers;
        private System.Windows.Forms.DataGridView dataGridViewTeachers;
        private System.Windows.Forms.DataGridView dataGridViewFaculty;
        private System.Windows.Forms.DataGridView dataGridViewCathedra;
        private System.Windows.Forms.DataGridView dataGridViewHours;
        private System.Windows.Forms.DataGridView dataGridViewWages;
        private System.Windows.Forms.Button buttonExit;

    }
}

